tempConversionFactor	0.5
{environment temperature (C)}	50 * tempConversionFactor
subscript	subfile.txt