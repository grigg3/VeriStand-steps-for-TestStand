{environment temperature (C)}	75
{idle speed (RPM)}	2000